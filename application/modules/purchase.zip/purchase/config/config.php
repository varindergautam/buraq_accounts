<?php
// module directory name
$HmvcConfig['purchase']["_title"]     = "purchase Details ";
$HmvcConfig['purchase']["_description"] = "Simple purchase processing System";
	  
$HmvcConfig['purchase']['_database'] = true;
$HmvcConfig['purchase']["_tables"] = array( 
	'product_purchase',
);
